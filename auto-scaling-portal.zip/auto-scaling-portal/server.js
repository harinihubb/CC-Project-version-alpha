const express = require("express");
const cors = require("cors");
const { injectLoad, togglePredictive, getMetrics } = require("./loadMonitor");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// simulate result access
app.get("/api/result", (req, res) => {
    injectLoad(Math.floor(Math.random() * 100));
    res.json({ message: "Result Loaded" });
});

// manual load simulation
app.post("/api/simulate", (req, res) => {
    injectLoad(req.body.users);
    res.json({ status: "Load injected" });
});

app.post("/api/toggle", (req, res) => {
    togglePredictive();
    res.json({ status: "Predictive mode toggled" });
});

app.get("/api/metrics", (req, res) => {
    res.json(getMetrics());
});

app.listen(3000, () => console.log("Server running on port 3000"));
