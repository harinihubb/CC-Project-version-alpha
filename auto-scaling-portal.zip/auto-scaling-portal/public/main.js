async function simulate(users) {
    await fetch("/api/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ users })
    });
}

async function toggle() {
    await fetch("/api/toggle", { method: "POST" });
}

async function updateMetrics() {
    const res = await fetch("/api/metrics");
    const data = await res.json();

    // Monitoring Page Metrics
    if (document.getElementById("metrics")) {
        document.getElementById("metrics").innerHTML = `
            <strong>Active Users:</strong> ${data.activeUsers}<br>
            <strong>CPU:</strong> ${data.cpuUsage}%<br>
            <strong>Memory:</strong> ${data.memoryUsage}%<br>
            <strong>Response Time:</strong> ${data.responseTime} ms<br>
            <strong>Instances:</strong> ${data.instances}<br>
            <strong>Mode:</strong> ${data.predictiveMode ? "Predictive" : "Reactive"}
        `;
    }

    // Landing Page Status Badge
    if (document.getElementById("statusBadge")) {
        let statusClass = "normal";
        let statusText = "Normal Load";

        if (data.cpuUsage > 70) {
            statusClass = "high";
            statusText = "High Load";
        }

        if (data.instances > 1) {
            statusClass = "scaling";
            statusText = "Scaling Active";
        }

        document.getElementById("statusBadge").innerHTML =
            `<span class="status-badge ${statusClass}">${statusText}</span>`;
    }

    if (document.getElementById("trafficCount")) {
        document.getElementById("trafficCount").innerText =
            `Active Users: ${data.activeUsers}`;
    }

    if (document.getElementById("scaleEvents")) {
        document.getElementById("scaleEvents").innerHTML =
            data.scaleEvents.slice(-3).map(e => `<div>${e.time} - ${e.message}</div>`).join("");
    }
}

setInterval(updateMetrics, 2000);
