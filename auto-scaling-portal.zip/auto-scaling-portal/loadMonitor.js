let metrics = {
    activeUsers: 0,
    cpuUsage: 10,
    memoryUsage: 20,
    responseTime: 100,
    instances: 1,
    predictiveMode: false,
    scaleEvents: [],
    history: []
};

function calculateMetrics(users) {
    metrics.activeUsers = users;
    metrics.cpuUsage = Math.min(100, users * 1.5);
    metrics.memoryUsage = Math.min(100, users * 1.2);
    metrics.responseTime = 100 + users * 5;

    // Simulated ML predictive logic
    if (metrics.predictiveMode) {
        if (users > 50 && metrics.instances < 3) {
            scaleUp("Predictive Scaling");
        }
    } else {
        if (metrics.cpuUsage > 70 && metrics.instances < 3) {
            scaleUp("Reactive Scaling");
        }
    }

    if (metrics.cpuUsage < 30 && metrics.instances > 1) {
        scaleDown();
    }

    metrics.history.push({
        time: Date.now(),
        cpu: metrics.cpuUsage,
        instances: metrics.instances,
        rps: users
    });

    if (metrics.history.length > 20) {
        metrics.history.shift();
    }
}

function scaleUp(type) {
    metrics.instances++;
    metrics.scaleEvents.push({
        time: new Date().toLocaleTimeString(),
        message: `${type} → Scale Up`
    });
}

function scaleDown() {
    metrics.instances--;
    metrics.scaleEvents.push({
        time: new Date().toLocaleTimeString(),
        message: "Scale Down"
    });
}

function injectLoad(users) {
    calculateMetrics(users);
}

function togglePredictive() {
    metrics.predictiveMode = !metrics.predictiveMode;
}

function getMetrics() {
    return metrics;
}

module.exports = { injectLoad, togglePredictive, getMetrics };
